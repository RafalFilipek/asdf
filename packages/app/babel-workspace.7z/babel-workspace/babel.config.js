module.exports = {
  babelrcRoots: [".", "./packages/*"],
};
