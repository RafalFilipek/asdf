module.exports = {
  presets: ["next/babel"],
};
