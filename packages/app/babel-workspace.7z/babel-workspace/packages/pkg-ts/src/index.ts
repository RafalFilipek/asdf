const foo: string = "ts-2";

export default foo;

export const bar = 3;
